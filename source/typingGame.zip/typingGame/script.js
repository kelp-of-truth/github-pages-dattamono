const tooltip=document.getElementById('tooltip');

const menuTop=document.getElementById('menuTop');
    const startBtn=document.getElementById('startBtn');
    const settingsBtn=document.getElementById('settingsBtn');
const difficulityTop=document.getElementById('difficulityTop');
    const difEasy=document.getElementById('difEasy');
    const difNormal=document.getElementById('difNormal');
    const difHard=document.getElementById('difHard');
    const difMaster=document.getElementById('difMaster');
const game=document.getElementById('game');
    const pleaseSpace=document.getElementById('pleaseSpacekey');
    const countDown=document.getElementById('countDown');
    const keyWord=document.getElementById('keyWord');

var openedMaster=0;
var difficulity=5;

var keyWords=[];

keyWords[0]=["昆布", "タイピング", "パソコン", "キーボード", "マウス", "ディスプレイ"];

var gameStandby=0;
difEasy.onclick=()=>{
    difficulityTop.hidden=true;
    game.hidden=false;
    difficulity=0;
    gameStandby=1;
};
document.onkeydown=(e)=>{
    if(gameStandby==1){
        if(e.key==" "){
            pleaseSpace.hidden=true;
            gameStandby=0;
            countDown.hidden=false;
            gameCountDown();
        };
        if(e.key=="Escape"){
            game.hidden=true;
            pleaseSpace.hidden=false;
            gameStandby=0;
            difficulityTop.hidden=false;
        };
    }else{

    }
};





function gameCountDown(){
    var standByCount=3;
    CountDown();
    function CountDown(){
        setTimeout(() => {
            standByCount-=1;
            countDown.innerHTML=String(standByCount);
            if(standByCount>0){
                CountDown();
            }else
            if(standByCount<=0){
                standByCount-=1;
                gameStart();
            };
        }, 1000);
    };
};


function gameStart(){
    countDown.hidden=true;
    keyWord.hidden=false;
}




startBtn.onclick=()=>{
    menuTop.hidden=true;
    difficulityTop.hidden=false;
};

difMaster.onmouseover=(e)=>{
    if(openedMaster==0){
        tooltip.hidden=false;
        tooltip.innerHTML="この難易度は難しいをクリアすると\n解放されます。";
        tooltip.style.left=e.pageX+"px";
        tooltip.style.top=e.pageY+"px";
    };
};
difMaster.onmousemove=(e)=>{
    if(openedMaster==0){
        tooltip.hidden=false;
        tooltip.innerHTML="この難易度は難しいをクリアすると<br>解放されます。";
        tooltip.style.left=e.pageX+10+"px";
        tooltip.style.top=e.pageY+10+"px";
    };
};
difMaster.onmouseout=(e)=>{
    tooltip.hidden=true;
};
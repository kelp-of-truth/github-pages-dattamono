$(".main").css("height", window.innerHeight+"px");
$(".main").css("width", window.innerWidth+"px");
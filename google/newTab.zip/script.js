$("#searchBox").on("focus", ()=>{
    $("#formInput").css("borderRadius", "0.7em")
    $("#history").attr("hidden", false);
})
$("#searchBox").on("blur", ()=>{
    setTimeout(() => {
        $("#formInput").css("borderRadius", "calc(1em + 6px)")
        $("#history").attr("hidden", true)  
    }, 1);
})
$(".historyList").on("mousedown", (e)=>{
    $("#searchBox").attr("value", (e.target.querySelectorAll("span")[0].innerHTML));
    setTimeout(() => {
        $("#searchBox").focus();
        document.getElementById('searchBox').setSelectionRange($("#searchBox").attr("length"), $("#searchBox").attr("length"))
    }, 5);
})
$(".historyList").on("mouseup", (e)=>{
    $("#searchSubmit").click();
})



// const suggest=new XMLHttpRequest();

// suggest.open("GET", "https://www.google.com/complete/search?hl=en&output=toolbar&", true);
// suggest.responseType="xml";
// suggest.send("google");

// suggest.onreadystatechange= function() {
//     setTimeout(() => {
//         alert(suggest.responseXML);
//         alert(document.children)
//     }, 100);
// };


// const suggest=new XMLHttpRequest();
// suggest.open("GET", "http://api.bing.com/osjson.aspx?market=ja-JP&query=hoge");
// suggest.send();

// suggest.onreadystatechange=()=>{
//     let responseJson=JSON.parse(suggest.responseText);
//     alert(responseJson);
//     alert("a")
// }
// getJson();
// function getJson() {
//     // alert("hoge")
//     //var xmlhttp = createXMLHttpRequest(); //旧バージョンのIEなどに対応する場合
//     var xmlhttp = new XMLHttpRequest();

//     xmlhttp.onreadystatechange = function () {
//       if (xmlhttp.readyState == 4) {
//           var data = JSON.parse(xmlhttp.responseText);

//             alert(data.keyword[0])
//         } else {
//         }
//     }
//     xmlhttp.open("GET", "http://api.bing.com/osjson.aspx?market=ja-JP&query=");
//     xmlhttp.send("hoge");
//   }

//   function createXMLHttpRequest() {
//     if (window.XMLHttpRequest) { return new XMLHttpRequest() }
//     if (window.ActiveXObject) {
//       try { return new ActiveXObject("Msxml2.XMLHTTP.6.0") } catch (e) { }
//       try { return new ActiveXObject("Msxml2.XMLHTTP.3.0") } catch (e) { }
//       try { return new ActiveXObject("Microsoft.XMLHTTP") } catch (e) { }
//     }
//     return false;
//   }





const suggest=new XMLHttpRequest();

suggest.open("GET", "http://api.bing.com/osjson.aspx?market=ja-JP&query=");
suggest.send("hoge");
alert(suggest);
setTimeout(() => {
    var data=suggest.response;
    alert(data)
}, 10);


var hoge=["keyword",["keywords","keyword tool","keywordmap","keyword planner","keyword map for sns","keyword can\u0027t be an expression","keyword surfer","keywords studios","keyword argument repeated","keywordtool.io","keyword finder","keywords html"],[],[],{"google:suggestrelevance":[1300,1299,1298,1297,1296,1295,1294,1293,1292,1291,1290,1289]}]
// JSON.parse(hoge);
// alert(hoge[1].length)